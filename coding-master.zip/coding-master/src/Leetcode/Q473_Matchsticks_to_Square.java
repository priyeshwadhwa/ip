package Leetcode;

/**
 * Created by rbhatnagar2 on 1/15/17.
 */
public class Q473_Matchsticks_to_Square {
}
