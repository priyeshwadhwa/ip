package Leetcode;

public class Q180_Consecutive_Numbers {
}
