package Leetcode;

public class Q433_Minimum_Genetic_Mutation {
}
