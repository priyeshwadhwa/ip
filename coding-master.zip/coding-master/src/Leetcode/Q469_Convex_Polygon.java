package Leetcode;

/**
 * Created by rbhatnagar2 on 3/15/17.
 */
public class Q469_Convex_Polygon {
}
