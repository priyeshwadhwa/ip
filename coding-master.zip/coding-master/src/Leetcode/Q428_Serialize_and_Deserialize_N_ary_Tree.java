package Leetcode;

public class Q428_Serialize_and_Deserialize_N_ary_Tree {
}
