package Leetcode;

public class Q185_Department_Top_Three_Salaries {
}
