package Leetcode;

public class Q489_Robot_Room_Cleaner {
}
