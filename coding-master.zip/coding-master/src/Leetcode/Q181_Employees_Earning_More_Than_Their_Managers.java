package Leetcode;

public class Q181_Employees_Earning_More_Than_Their_Managers {
}
