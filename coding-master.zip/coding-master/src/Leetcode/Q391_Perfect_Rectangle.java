package Leetcode;

/**
 * Created by rbhatnagar2 on 1/15/17.
 */
public class Q391_Perfect_Rectangle {
}
