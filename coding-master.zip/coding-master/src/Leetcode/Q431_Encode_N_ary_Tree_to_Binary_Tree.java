package Leetcode;

public class Q431_Encode_N_ary_Tree_to_Binary_Tree {
}
