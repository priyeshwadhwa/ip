package Leetcode;

public class Q458_Poor_Pigs {
}
