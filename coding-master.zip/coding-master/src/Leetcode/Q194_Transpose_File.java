package Leetcode;

public class Q194_Transpose_File {
}
