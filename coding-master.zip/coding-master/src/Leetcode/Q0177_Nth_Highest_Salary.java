package Leetcode;

public class Q0177_Nth_Highest_Salary {
}
