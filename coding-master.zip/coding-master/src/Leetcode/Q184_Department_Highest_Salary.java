package Leetcode;

public class Q184_Department_Highest_Salary {
}
