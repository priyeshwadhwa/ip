package Leetcode;

public class Q430_Flatten_a_Multilevel_Doubly_Linked_List {
}
