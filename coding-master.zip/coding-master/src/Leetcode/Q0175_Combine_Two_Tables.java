package Leetcode;

public class Q0175_Combine_Two_Tables {
}
