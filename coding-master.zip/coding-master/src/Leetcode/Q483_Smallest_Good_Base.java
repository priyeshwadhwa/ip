package Leetcode;

/**
 * Created by rbhatnagar2 on 1/15/17.
 */
public class Q483_Smallest_Good_Base {
}
