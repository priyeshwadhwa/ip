package Leetcode;

public class Q0176_Second_Highest_Salary {
}
