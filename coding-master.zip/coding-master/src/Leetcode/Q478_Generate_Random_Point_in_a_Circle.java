package Leetcode;

public class Q478_Generate_Random_Point_in_a_Circle {
}
