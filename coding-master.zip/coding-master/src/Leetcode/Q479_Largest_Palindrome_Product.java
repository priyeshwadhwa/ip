package Leetcode;

public class Q479_Largest_Palindrome_Product {
}
