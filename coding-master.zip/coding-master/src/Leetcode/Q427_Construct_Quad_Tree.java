package Leetcode;

public class Q427_Construct_Quad_Tree {
}
