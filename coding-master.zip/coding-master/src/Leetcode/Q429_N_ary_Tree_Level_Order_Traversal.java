package Leetcode;

public class Q429_N_ary_Tree_Level_Order_Traversal {
}
