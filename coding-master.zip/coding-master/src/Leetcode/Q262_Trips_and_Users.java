package Leetcode;

public class Q262_Trips_and_Users {
}
