package Leetcode;

/**
 * Created by rbhatnagar2 on 3/15/17.
 */
public class Q296_Best_Meeting_Point {
}
