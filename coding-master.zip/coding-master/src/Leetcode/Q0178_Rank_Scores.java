package Leetcode;

public class Q0178_Rank_Scores {
}
