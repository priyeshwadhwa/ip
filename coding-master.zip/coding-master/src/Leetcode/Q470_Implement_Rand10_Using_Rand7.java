package Leetcode;

public class Q470_Implement_Rand10_Using_Rand7 {
}
