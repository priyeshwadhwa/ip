package Leetcode;

public class Q182_Duplicate_Emails {
}
