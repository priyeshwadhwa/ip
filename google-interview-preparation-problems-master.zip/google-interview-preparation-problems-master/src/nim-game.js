// https://leetcode.com/problems/nim-game/description/

const canWinNim = n => n % 4 !== 0;

console.log(canWinNim(4));