Momotonous Array

判断 个序 是否是递增递减序 

就一个Boolean flag表示是否已经确定了方向以及方向是什么，从前往后搜。